"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/shared/improveError.ts
  function isImproveErrorCode(value) {
    return typeof value === "string" && value in DISPLAY_MESSAGES;
  }
  function getErrorMessage(error) {
    if (error instanceof Error) {
      return error.message;
    }
    const message = error?.message;
    if (typeof message === "string") {
      return message;
    }
    return String(error);
  }
  function normalizeReliableLLMError(error) {
    switch (error.type) {
      case "AUTHENTICATION":
        return new ImproveError("AUTHENTICATION", error.message);
      case "RATE_LIMIT":
      case "QUOTA_EXCEEDED":
        return new ImproveError("RATE_LIMITED", error.message);
      case "NETWORK":
        return new ImproveError("NETWORK_ERROR", error.message);
      case "UNSUPPORTED":
      case "UNKNOWN":
      default:
        return new ImproveError("UNKNOWN", error.message);
    }
  }
  function normalizeImproveError(error) {
    if (error instanceof ImproveError) {
      return error;
    }
    const reliableType = error?.type;
    if (typeof reliableType === "string") {
      return normalizeReliableLLMError({ type: reliableType, message: getErrorMessage(error) });
    }
    const errorCode = error?.errorCode;
    const message = getErrorMessage(error);
    if (isImproveErrorCode(errorCode)) {
      return new ImproveError(errorCode, message);
    }
    return new ImproveError("UNKNOWN", message);
  }
  var DISPLAY_MESSAGES, ImproveError;
  var init_improveError = __esm({
    "src/shared/improveError.ts"() {
      "use strict";
      DISPLAY_MESSAGES = {
        RATE_LIMITED: "This improve is rate limited. Please try again later.",
        KEY_NOT_READY: "Setting up your API key... please try again in a moment.",
        NETWORK_ERROR: "Network error. Check your connection and try again.",
        INPUT_EMPTY: "Enter a prompt to improve.",
        INPUT_TOO_LONG: "Input exceeds 500 tokens. Shorten and try again.",
        AUTHENTICATION: "API key invalid or unavailable. Try again in a moment.",
        UNKNOWN: "Improving failed. Please try again."
      };
      ImproveError = class extends Error {
        constructor(errorCode, debugMessage, displayMessage = DISPLAY_MESSAGES[errorCode]) {
          super(debugMessage);
          this.name = "ImproveError";
          this.errorCode = errorCode;
          this.displayMessage = displayMessage;
          this.debugMessage = debugMessage;
        }
      };
    }
  });

  // src/shared/serviceBus.ts
  var ServiceBus;
  var init_serviceBus = __esm({
    "src/shared/serviceBus.ts"() {
      "use strict";
      init_improveError();
      ServiceBus = class {
        /**
         * Send a request to the background script to improve a prompt
         */
        static async improvePrompt(text, context) {
          const response = await this.send({
            type: "IMPROVE_PROMPT" /* IMPROVE_PROMPT */,
            payload: { text, context }
          });
          if (!response.success) {
            const error = new Error(response.error || "Failed to improve prompt");
            error.errorCode = response.errorCode;
            error.debugMessage = response.debugMessage;
            throw error;
          }
          return response.data;
        }
        /**
         * Generic internal sender using long-lived ports for disconnect awareness
         */
        static send(message) {
          return new Promise((resolve, reject) => {
            const port = chrome.runtime.connect({ name: message.type });
            port.onMessage.addListener((response) => {
              port.disconnect();
              resolve(response);
            });
            port.onDisconnect.addListener(() => {
              if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message || "";
                if (errMsg.includes("Extension context invalidated")) {
                  reject(new Error("Extension was updated. Please refresh this page to continue using Prompt Easy."));
                } else {
                  reject(new Error(errMsg));
                }
              } else {
                reject(new Error("Connection to service worker lost."));
              }
            });
            port.postMessage(message);
          });
        }
        /**
         * Helper for background script to listen for typed messages.
         * The handler receives (type, payload, abortSignal) where abortSignal
         * fires when the caller disconnects (e.g., popup closes).
         */
        static addListener(handler) {
          chrome.runtime.onConnect.addListener((port) => {
            const abortController = new AbortController();
            port.onDisconnect.addListener(() => {
              abortController.abort();
            });
            port.onMessage.addListener((message) => {
              handler(message.type, message.payload, abortController.signal).then((data) => port.postMessage({ success: true, data })).catch((error) => {
                if (abortController.signal.aborted) {
                  return;
                }
                const improveError = normalizeImproveError(error);
                port.postMessage({
                  success: false,
                  error: improveError.displayMessage,
                  errorCode: improveError.errorCode,
                  debugMessage: improveError.debugMessage
                });
              });
            });
          });
        }
      };
    }
  });

  // src/shared/config.ts
  var CONFIG_ENDPOINT_URL;
  var init_config = __esm({
    "src/shared/config.ts"() {
      "use strict";
      CONFIG_ENDPOINT_URL = false ? "https://prompt-easy-config.razparkr.workers.dev" : "https://prompt-easy-config.razparkr.workers.dev";
    }
  });

  // src/shared/storage.ts
  var StorageWrapper;
  var init_storage = __esm({
    "src/shared/storage.ts"() {
      "use strict";
      StorageWrapper = class {
        static setLocal(key, value) {
          return new Promise((resolve, reject) => {
            chrome.storage.local.set({ [key]: value }, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          });
        }
        static getLocal(key) {
          return new Promise((resolve, reject) => {
            chrome.storage.local.get([key], (result) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(result[key]);
              }
            });
          });
        }
        static setSession(key, value) {
          return new Promise((resolve, reject) => {
            chrome.storage.session.set({ [key]: value }, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          });
        }
        static getSession(key) {
          return new Promise((resolve, reject) => {
            chrome.storage.session.get([key], (result) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(result[key]);
              }
            });
          });
        }
        static removeSession(key) {
          return new Promise((resolve, reject) => {
            chrome.storage.session.remove(key, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          });
        }
      };
    }
  });

  // src/shared/promptEasyStorage.ts
  var LOCAL_KEYS, SESSION_KEYS, PromptEasyStorage;
  var init_promptEasyStorage = __esm({
    "src/shared/promptEasyStorage.ts"() {
      "use strict";
      init_storage();
      LOCAL_KEYS = {
        MANAGED_CONFIG: "managedConfig",
        KEY_FETCH_FAILED: "keyFetchFailed",
        LAST_KEY_CHECK: "lastKeyCheck",
        DAILY_USAGE_COUNT: "dailyUsageCount",
        USAGE_DATE: "usageDate",
        TOTAL_CALLS: "totalCalls",
        TOKENS_IN: "estimatedTokensIn",
        TOKENS_OUT: "estimatedTokensOut"
      };
      SESSION_KEYS = {
        LEGACY_SESSION_KEY: "sessionApiKey"
      };
      PromptEasyStorage = class {
        static async getManagedConfig() {
          const config = await StorageWrapper.getLocal(LOCAL_KEYS.MANAGED_CONFIG);
          return config || null;
        }
        static async setManagedConfig(config) {
          await StorageWrapper.setLocal(LOCAL_KEYS.MANAGED_CONFIG, config);
        }
        static async markKeyFetchFailed() {
          await StorageWrapper.setLocal(LOCAL_KEYS.KEY_FETCH_FAILED, true);
        }
        static async setLastKeyCheck(timestamp) {
          await StorageWrapper.setLocal(LOCAL_KEYS.LAST_KEY_CHECK, timestamp);
        }
        static async getLastKeyCheck() {
          const lastCheck = await StorageWrapper.getLocal(LOCAL_KEYS.LAST_KEY_CHECK);
          return lastCheck || null;
        }
        static async purgeLegacySessionKey() {
          await StorageWrapper.removeSession(SESSION_KEYS.LEGACY_SESSION_KEY);
        }
        static async getDailyUsage() {
          const [count, date] = await Promise.all([
            StorageWrapper.getLocal(LOCAL_KEYS.DAILY_USAGE_COUNT),
            StorageWrapper.getLocal(LOCAL_KEYS.USAGE_DATE)
          ]);
          return {
            count: count || 0,
            date: date || void 0
          };
        }
        static async setDailyUsage(usage) {
          await Promise.all([
            StorageWrapper.setLocal(LOCAL_KEYS.DAILY_USAGE_COUNT, usage.count),
            StorageWrapper.setLocal(LOCAL_KEYS.USAGE_DATE, usage.date)
          ]);
        }
        static async getUsageStats() {
          const [totalCalls, estimatedTokensIn, estimatedTokensOut] = await Promise.all([
            StorageWrapper.getLocal(LOCAL_KEYS.TOTAL_CALLS),
            StorageWrapper.getLocal(LOCAL_KEYS.TOKENS_IN),
            StorageWrapper.getLocal(LOCAL_KEYS.TOKENS_OUT)
          ]);
          return {
            totalCalls: totalCalls || 0,
            estimatedTokensIn: estimatedTokensIn || 0,
            estimatedTokensOut: estimatedTokensOut || 0
          };
        }
        static async setUsageStats(stats) {
          await Promise.all([
            StorageWrapper.setLocal(LOCAL_KEYS.TOTAL_CALLS, stats.totalCalls),
            StorageWrapper.setLocal(LOCAL_KEYS.TOKENS_IN, stats.estimatedTokensIn),
            StorageWrapper.setLocal(LOCAL_KEYS.TOKENS_OUT, stats.estimatedTokensOut)
          ]);
        }
        static async incrementUsageStats(inputTokens, outputTokens) {
          const stats = await this.getUsageStats();
          await this.setUsageStats({
            totalCalls: stats.totalCalls + 1,
            estimatedTokensIn: stats.estimatedTokensIn + inputTokens,
            estimatedTokensOut: stats.estimatedTokensOut + outputTokens
          });
        }
        static async resetUsageStats() {
          await this.setUsageStats({
            totalCalls: 0,
            estimatedTokensIn: 0,
            estimatedTokensOut: 0
          });
        }
      };
    }
  });

  // src/shared/configManager.ts
  var ConfigManager;
  var init_configManager = __esm({
    "src/shared/configManager.ts"() {
      "use strict";
      init_config();
      init_promptEasyStorage();
      ConfigManager = class {
        static async getManagedConfig() {
          return PromptEasyStorage.getManagedConfig();
        }
        static async ensureKey() {
          const config = await this.getManagedConfig();
          if (config?.apiKey) {
            return config.apiKey;
          }
          if (this.pendingFetch) {
            const result = await this.pendingFetch;
            return result.apiKey;
          }
          this.pendingFetch = this.fetchAndCacheConfig();
          try {
            const result = await this.pendingFetch;
            return result.apiKey;
          } finally {
            this.pendingFetch = null;
          }
        }
        static async fetchAndCacheConfig() {
          try {
            const response = await fetch(CONFIG_ENDPOINT_URL);
            if (!response.ok) {
              throw new Error(`HTTP ${response.status}`);
            }
            const config = await response.json();
            await PromptEasyStorage.setManagedConfig(config);
            return config;
          } catch (error) {
            await PromptEasyStorage.markKeyFetchFailed();
            throw new Error(`Failed to fetch API key configuration: ${error.message}`);
          }
        }
        static resetForTest() {
          this.pendingFetch = null;
        }
      };
      ConfigManager.pendingFetch = null;
    }
  });

  // src/shared/rateLimiter.ts
  var RateLimitError, RateLimiter;
  var init_rateLimiter = __esm({
    "src/shared/rateLimiter.ts"() {
      "use strict";
      init_promptEasyStorage();
      RateLimitError = class extends Error {
        constructor(message) {
          super(message);
          this.name = "RateLimitError";
          this.errorCode = "RATE_LIMITED";
        }
      };
      RateLimiter = class {
        // Set to false to enable rate limiting
        static async checkAndIncrement() {
          if (this.DISABLED) return;
          const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
          const usage = await PromptEasyStorage.getDailyUsage();
          if (usage.date !== today) {
            await PromptEasyStorage.setDailyUsage({ count: 1, date: today });
            return;
          }
          if (usage.count >= this.DAILY_LIMIT) {
            throw new RateLimitError("Daily improve limit reached. Try again tomorrow.");
          }
          await PromptEasyStorage.setDailyUsage({ count: usage.count + 1, date: today });
        }
      };
      RateLimiter.DAILY_LIMIT = 3;
      RateLimiter.DISABLED = true;
    }
  });

  // src/shared/settingsStore.ts
  var SettingsStore;
  var init_settingsStore = __esm({
    "src/shared/settingsStore.ts"() {
      "use strict";
      init_promptEasyStorage();
      SettingsStore = class {
        static async getUsageStats() {
          return PromptEasyStorage.getUsageStats();
        }
        static async updateUsage(inputTokens, outputTokens) {
          await PromptEasyStorage.incrementUsageStats(inputTokens, outputTokens);
        }
        static async resetUsage() {
          await PromptEasyStorage.resetUsageStats();
        }
      };
    }
  });

  // src/shared/reliableLLMClient.ts
  var ReliableLLMError, ReliableLLMClient;
  var init_reliableLLMClient = __esm({
    "src/shared/reliableLLMClient.ts"() {
      "use strict";
      ReliableLLMError = class extends Error {
        constructor(type, message) {
          super(message);
          this.type = type;
          this.name = "ReliableLLMError";
        }
      };
      ReliableLLMClient = class {
        constructor(options) {
          this.options = options;
          this.maxRetries = options.maxRetries ?? 1;
        }
        async execute(prompt, executeOptions) {
          let attempts = 0;
          let lastError = null;
          const apiKey = await this.resolveApiKey();
          while (attempts <= this.maxRetries) {
            if (this.options.signal?.aborted) {
              throw new ReliableLLMError("UNKNOWN" /* UNKNOWN */, "Request cancelled by caller.");
            }
            try {
              const result = await this.callProvider(prompt, apiKey, executeOptions?.systemInstruction);
              return result;
            } catch (error) {
              if (this.options.signal?.aborted) {
                throw new ReliableLLMError("UNKNOWN" /* UNKNOWN */, "Request cancelled by caller.");
              }
              const normalizedError = this.normalizeError(error);
              lastError = normalizedError;
              const shouldRetry = (normalizedError.type === "NETWORK" /* NETWORK */ || normalizedError.type === "RATE_LIMIT" /* RATE_LIMIT */) && attempts < this.maxRetries;
              if (shouldRetry) {
                attempts++;
                const delay = Math.pow(2, attempts - 1) * 1e3;
                await new Promise((res) => {
                  const timer = setTimeout(res, delay);
                  this.options.signal?.addEventListener("abort", () => {
                    clearTimeout(timer);
                    res(void 0);
                  }, { once: true });
                });
                continue;
              }
              throw normalizedError;
            }
          }
          throw lastError;
        }
        async resolveApiKey() {
          if (!this.options.apiKey) {
            throw new ReliableLLMError("AUTHENTICATION" /* AUTHENTICATION */, "API key unavailable.");
          }
          return this.options.apiKey;
        }
        async callProvider(prompt, apiKey, systemInstruction) {
          if (this.options.provider !== "google") {
            throw new ReliableLLMError("UNSUPPORTED" /* UNSUPPORTED */, `Provider ${this.options.provider} not implemented.`);
          }
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.options.model}:generateContent?key=${apiKey}`;
          const timeoutSignal = AbortSignal.timeout(1e4);
          const body = {
            contents: [{ parts: [{ text: prompt }] }]
          };
          if (systemInstruction) {
            body.systemInstruction = { parts: [{ text: systemInstruction }] };
          }
          const response = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
            signal: timeoutSignal
          });
          if (!response.ok) {
            let errorMessage = `HTTP ${response.status}`;
            try {
              const errorBody = await response.json();
              if (errorBody.error?.message) {
                errorMessage = errorBody.error.message;
              }
            } catch {
            }
            throw Object.assign(new Error(errorMessage), { status: response.status });
          }
          const data = await response.json();
          const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
          if (!text) {
            throw new Error("Empty response from Gemini");
          }
          return {
            text: text.trim(),
            usage: {
              inputTokens: Math.ceil((systemInstruction ? `${systemInstruction}

${prompt}` : prompt).length / 4),
              outputTokens: Math.ceil(text.length / 4)
            }
          };
        }
        normalizeError(error) {
          const status = error.status;
          if (status) {
            if (status === 400 || status === 401 || status === 403) {
              return new ReliableLLMError("AUTHENTICATION" /* AUTHENTICATION */, error.message || "Authentication failed.");
            }
            if (status === 429) {
              return new ReliableLLMError("RATE_LIMIT" /* RATE_LIMIT */, error.message || "Rate limit exceeded.");
            }
            if (status === 500 || status === 502 || status === 503) {
              return new ReliableLLMError("NETWORK" /* NETWORK */, error.message || "Network connection failed.");
            }
            return new ReliableLLMError("UNKNOWN" /* UNKNOWN */, error.message || `HTTP ${status}`);
          }
          if (error.name === "AbortError" || error.name === "TimeoutError") {
            return new ReliableLLMError("NETWORK" /* NETWORK */, "Request timed out.");
          }
          const msg = error.message || String(error);
          if (msg.includes("fetch failed") || msg.includes("Network error") || msg.includes("ECONNREFUSED") || msg.includes("timed out")) {
            return new ReliableLLMError("NETWORK" /* NETWORK */, "Network connection failed.");
          }
          return new ReliableLLMError("UNKNOWN" /* UNKNOWN */, msg);
        }
      };
    }
  });

  // src/template.ts
  function hasText(value) {
    return typeof value === "string" && value.trim().length > 0;
  }
  function buildContextCards(input) {
    const contextCards = (input.contextCards ?? []).filter((card) => hasText(card.name) && hasText(card.text)).map((card) => ({
      name: card.name.trim(),
      text: card.text.trim()
    }));
    if (hasText(input.context)) {
      contextCards.unshift({
        name: "User Context",
        text: input.context.trim()
      });
    }
    return contextCards;
  }
  function renderContextCards(contextCards) {
    if (contextCards.length === 0) {
      return "";
    }
    const renderedCards = contextCards.map((card) => `- ${card.name}: ${card.text}`).join("\n");
    return `

CONTEXT CARDS:
${renderedCards}`;
  }
  function renderImproveTemplate(input = {}) {
    const contextCards = buildContextCards(input);
    const outputFormatLines = [
      "1. ROLE: Define a specific persona or expertise the AI should adopt",
      "2. TASK: Clarify the exact deliverable or action",
      "3. OUTPUT FORMAT: Specify format, length, tone",
      "4. CONSTRAINTS: Specify any specific requirements or limitations",
      ...contextCards.length > 0 ? ["5. CONTEXT: Inject the provided Context Cards only when they are relevant"] : []
    ];
    return `You are an expert prompt engineer. Your task is to improve the user's vague prompt into a structured, effective prompt.

OUTPUT FORMAT:
Return the improved prompt with exactly these sections:
${outputFormatLines.join("\n")}

IMPORTANT:
- Preserve the original language. Do NOT translate.
- Preserve the user's intent and important keywords.
- Return ONLY the improved prompt text.
- Target output around 200 tokens.${renderContextCards(contextCards)}`;
  }
  var init_template = __esm({
    "src/template.ts"() {
      "use strict";
    }
  });

  // src/improveEngine.ts
  var PromptEasyEngine;
  var init_improveEngine = __esm({
    "src/improveEngine.ts"() {
      "use strict";
      init_configManager();
      init_improveError();
      init_rateLimiter();
      init_settingsStore();
      init_reliableLLMClient();
      init_template();
      PromptEasyEngine = class {
        constructor(config = {}) {
          this.MAX_INPUT_TOKENS = 500;
          this.provider = config.provider || "google";
        }
        /**
         * Improves a vague prompt into a structured, effective prompt.
         * 
         * @param prompt - The vague input prompt
         * @param options - Optional configuration (e.g., context cards)
         * @returns A promise that resolves to the improved prompt string
         */
        async improve(prompt, options) {
          try {
            this.validatePrompt(prompt);
            await RateLimiter.checkAndIncrement();
            const managedConfig = await this.getReadyConfig();
            const activeModel = managedConfig.model || "gemini-2.0-flash";
            const client = new ReliableLLMClient({
              provider: this.provider,
              model: activeModel,
              apiKey: managedConfig.apiKey,
              signal: options?.signal
            });
            const systemInstruction = renderImproveTemplate({
              context: options?.context,
              contextCards: options?.contextCards
            });
            const result = await client.execute(prompt, { systemInstruction });
            SettingsStore.updateUsage(result.usage.inputTokens, result.usage.outputTokens).catch(console.error);
            return result.text;
          } catch (error) {
            throw normalizeImproveError(error);
          }
        }
        validatePrompt(prompt) {
          if (!prompt || prompt.trim().length === 0) {
            throw new ImproveError("INPUT_EMPTY", "Prompt cannot be empty");
          }
          const estimatedTokens = Math.ceil(prompt.length / 4);
          if (estimatedTokens > this.MAX_INPUT_TOKENS) {
            throw new ImproveError(
              "INPUT_TOO_LONG",
              `Input too long (estimated ${estimatedTokens} tokens). Max is ${this.MAX_INPUT_TOKENS}.`
            );
          }
        }
        async getReadyConfig() {
          const config = await ConfigManager.getManagedConfig();
          if (config?.apiKey) {
            return config;
          }
          try {
            const apiKey = await ConfigManager.ensureKey();
            const healedConfig = await ConfigManager.getManagedConfig();
            return {
              apiKey,
              model: healedConfig?.model
            };
          } catch (error) {
            throw new ImproveError("KEY_NOT_READY", `API key not ready: ${error.message}`);
          }
        }
      };
    }
  });

  // src/background/provisioningService.ts
  var ProvisioningService;
  var init_provisioningService = __esm({
    "src/background/provisioningService.ts"() {
      "use strict";
      init_configManager();
      init_promptEasyStorage();
      ProvisioningService = class {
        static async handleInstalled(details) {
          if (details.reason === "install") {
            const success = await this.fetchWithRetry();
            if (success) {
              await this.scheduleDailyAlarm();
            }
          } else if (details.reason === "update") {
            await PromptEasyStorage.purgeLegacySessionKey();
            const success = await this.fetchWithRetry();
            if (success) {
              await this.scheduleDailyAlarm();
            }
          }
        }
        static async fetchWithRetry() {
          for (let attempt = 1; attempt <= this.MAX_RETRIES; attempt++) {
            try {
              await ConfigManager.ensureKey();
              await PromptEasyStorage.setLastKeyCheck(Date.now());
              return true;
            } catch {
              if (attempt < this.MAX_RETRIES) {
                const delay = this.BASE_DELAY_MS * Math.pow(2, attempt - 1);
                await this.sleep(delay);
              }
            }
          }
          await PromptEasyStorage.markKeyFetchFailed();
          return false;
        }
        static async scheduleDailyAlarm() {
          chrome.alarms.create(this.ALARM_NAME, { periodInMinutes: 24 * 60 });
        }
        static async handleAlarm(alarm) {
          if (alarm.name !== this.ALARM_NAME) {
            return;
          }
          const lastCheck = await PromptEasyStorage.getLastKeyCheck();
          if (lastCheck && Date.now() - lastCheck < this.TWENTY_FOUR_HOURS_MS) {
            return;
          }
          await this.fetchWithRetry();
        }
        static sleep(ms) {
          return new Promise((resolve) => setTimeout(resolve, ms));
        }
        static resetForTest() {
          ConfigManager.resetForTest();
        }
      };
      ProvisioningService.MAX_RETRIES = 3;
      ProvisioningService.BASE_DELAY_MS = 1e3;
      ProvisioningService.ALARM_NAME = "daily-key-refresh";
      ProvisioningService.TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1e3;
    }
  });

  // src/background/service-worker.ts
  var require_service_worker = __commonJS({
    "src/background/service-worker.ts"() {
      init_serviceBus();
      init_improveEngine();
      init_provisioningService();
      console.log("Prompt Easy: Service Worker initialized with ServiceBus");
      chrome.runtime.onInstalled.addListener(async (details) => {
        await ProvisioningService.handleInstalled(details);
      });
      chrome.alarms.onAlarm.addListener(async (alarm) => {
        await ProvisioningService.handleAlarm(alarm);
      });
      ServiceBus.addListener(async (type, payload, abortSignal) => {
        if (type === "PING" /* PING */) {
          return "PONG";
        }
        if (type === "IMPROVE_PROMPT" /* IMPROVE_PROMPT */) {
          const { text, context } = payload;
          const engine = new PromptEasyEngine();
          return await engine.improve(text, { context, signal: abortSignal });
        }
        throw new Error(`Unhandled message type: ${type}`);
      });
    }
  });
  require_service_worker();
})();
//# sourceMappingURL=service-worker.js.map

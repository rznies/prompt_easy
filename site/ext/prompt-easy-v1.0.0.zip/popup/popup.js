"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/shared/improveError.ts
  function isImproveErrorCode(value) {
    return typeof value === "string" && value in DISPLAY_MESSAGES;
  }
  function getErrorMessage(error) {
    if (error instanceof Error) {
      return error.message;
    }
    const message = error?.message;
    if (typeof message === "string") {
      return message;
    }
    return String(error);
  }
  function normalizeReliableLLMError(error) {
    switch (error.type) {
      case "AUTHENTICATION":
        return new ImproveError("AUTHENTICATION", error.message);
      case "RATE_LIMIT":
      case "QUOTA_EXCEEDED":
        return new ImproveError("RATE_LIMITED", error.message);
      case "NETWORK":
        return new ImproveError("NETWORK_ERROR", error.message);
      case "UNSUPPORTED":
      case "UNKNOWN":
      default:
        return new ImproveError("UNKNOWN", error.message);
    }
  }
  function normalizeImproveError(error) {
    if (error instanceof ImproveError) {
      return error;
    }
    const reliableType = error?.type;
    if (typeof reliableType === "string") {
      return normalizeReliableLLMError({ type: reliableType, message: getErrorMessage(error) });
    }
    const errorCode = error?.errorCode;
    const message = getErrorMessage(error);
    if (isImproveErrorCode(errorCode)) {
      return new ImproveError(errorCode, message);
    }
    return new ImproveError("UNKNOWN", message);
  }
  function getImproveErrorDisplayMessage(error) {
    return normalizeImproveError(error).displayMessage;
  }
  var DISPLAY_MESSAGES, ImproveError;
  var init_improveError = __esm({
    "src/shared/improveError.ts"() {
      "use strict";
      DISPLAY_MESSAGES = {
        RATE_LIMITED: "This improve is rate limited. Please try again later.",
        KEY_NOT_READY: "Setting up your API key... please try again in a moment.",
        NETWORK_ERROR: "Network error. Check your connection and try again.",
        INPUT_EMPTY: "Enter a prompt to improve.",
        INPUT_TOO_LONG: "Input exceeds 500 tokens. Shorten and try again.",
        AUTHENTICATION: "API key invalid or unavailable. Try again in a moment.",
        UNKNOWN: "Improving failed. Please try again."
      };
      ImproveError = class extends Error {
        constructor(errorCode, debugMessage, displayMessage = DISPLAY_MESSAGES[errorCode]) {
          super(debugMessage);
          this.name = "ImproveError";
          this.errorCode = errorCode;
          this.displayMessage = displayMessage;
          this.debugMessage = debugMessage;
        }
      };
    }
  });

  // src/shared/serviceBus.ts
  var ServiceBus;
  var init_serviceBus = __esm({
    "src/shared/serviceBus.ts"() {
      "use strict";
      init_improveError();
      ServiceBus = class {
        /**
         * Send a request to the background script to improve a prompt
         */
        static async improvePrompt(text, context) {
          const response = await this.send({
            type: "IMPROVE_PROMPT" /* IMPROVE_PROMPT */,
            payload: { text, context }
          });
          if (!response.success) {
            const error = new Error(response.error || "Failed to improve prompt");
            error.errorCode = response.errorCode;
            error.debugMessage = response.debugMessage;
            throw error;
          }
          return response.data;
        }
        /**
         * Generic internal sender using long-lived ports for disconnect awareness
         */
        static send(message) {
          return new Promise((resolve, reject) => {
            const port = chrome.runtime.connect({ name: message.type });
            port.onMessage.addListener((response) => {
              port.disconnect();
              resolve(response);
            });
            port.onDisconnect.addListener(() => {
              if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message || "";
                if (errMsg.includes("Extension context invalidated")) {
                  reject(new Error("Extension was updated. Please refresh this page to continue using Prompt Easy."));
                } else {
                  reject(new Error(errMsg));
                }
              } else {
                reject(new Error("Connection to service worker lost."));
              }
            });
            port.postMessage(message);
          });
        }
        /**
         * Helper for background script to listen for typed messages.
         * The handler receives (type, payload, abortSignal) where abortSignal
         * fires when the caller disconnects (e.g., popup closes).
         */
        static addListener(handler) {
          chrome.runtime.onConnect.addListener((port) => {
            const abortController = new AbortController();
            port.onDisconnect.addListener(() => {
              abortController.abort();
            });
            port.onMessage.addListener((message) => {
              handler(message.type, message.payload, abortController.signal).then((data) => port.postMessage({ success: true, data })).catch((error) => {
                if (abortController.signal.aborted) {
                  return;
                }
                const improveError = normalizeImproveError(error);
                port.postMessage({
                  success: false,
                  error: improveError.displayMessage,
                  errorCode: improveError.errorCode,
                  debugMessage: improveError.debugMessage
                });
              });
            });
          });
        }
      };
    }
  });

  // src/shared/config.ts
  var CONFIG_ENDPOINT_URL;
  var init_config = __esm({
    "src/shared/config.ts"() {
      "use strict";
      CONFIG_ENDPOINT_URL = false ? "https://prompt-easy-config.razparkr.workers.dev" : "https://prompt-easy-config.razparkr.workers.dev";
    }
  });

  // src/shared/storage.ts
  var StorageWrapper;
  var init_storage = __esm({
    "src/shared/storage.ts"() {
      "use strict";
      StorageWrapper = class {
        static setLocal(key, value) {
          return new Promise((resolve, reject) => {
            chrome.storage.local.set({ [key]: value }, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          });
        }
        static getLocal(key) {
          return new Promise((resolve, reject) => {
            chrome.storage.local.get([key], (result) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(result[key]);
              }
            });
          });
        }
        static setSession(key, value) {
          return new Promise((resolve, reject) => {
            chrome.storage.session.set({ [key]: value }, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          });
        }
        static getSession(key) {
          return new Promise((resolve, reject) => {
            chrome.storage.session.get([key], (result) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(result[key]);
              }
            });
          });
        }
        static removeSession(key) {
          return new Promise((resolve, reject) => {
            chrome.storage.session.remove(key, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          });
        }
      };
    }
  });

  // src/shared/promptEasyStorage.ts
  var LOCAL_KEYS, SESSION_KEYS, PromptEasyStorage;
  var init_promptEasyStorage = __esm({
    "src/shared/promptEasyStorage.ts"() {
      "use strict";
      init_storage();
      LOCAL_KEYS = {
        MANAGED_CONFIG: "managedConfig",
        KEY_FETCH_FAILED: "keyFetchFailed",
        LAST_KEY_CHECK: "lastKeyCheck",
        DAILY_USAGE_COUNT: "dailyUsageCount",
        USAGE_DATE: "usageDate",
        TOTAL_CALLS: "totalCalls",
        TOKENS_IN: "estimatedTokensIn",
        TOKENS_OUT: "estimatedTokensOut"
      };
      SESSION_KEYS = {
        LEGACY_SESSION_KEY: "sessionApiKey"
      };
      PromptEasyStorage = class {
        static async getManagedConfig() {
          const config = await StorageWrapper.getLocal(LOCAL_KEYS.MANAGED_CONFIG);
          return config || null;
        }
        static async setManagedConfig(config) {
          await StorageWrapper.setLocal(LOCAL_KEYS.MANAGED_CONFIG, config);
        }
        static async markKeyFetchFailed() {
          await StorageWrapper.setLocal(LOCAL_KEYS.KEY_FETCH_FAILED, true);
        }
        static async setLastKeyCheck(timestamp) {
          await StorageWrapper.setLocal(LOCAL_KEYS.LAST_KEY_CHECK, timestamp);
        }
        static async getLastKeyCheck() {
          const lastCheck = await StorageWrapper.getLocal(LOCAL_KEYS.LAST_KEY_CHECK);
          return lastCheck || null;
        }
        static async purgeLegacySessionKey() {
          await StorageWrapper.removeSession(SESSION_KEYS.LEGACY_SESSION_KEY);
        }
        static async getDailyUsage() {
          const [count, date] = await Promise.all([
            StorageWrapper.getLocal(LOCAL_KEYS.DAILY_USAGE_COUNT),
            StorageWrapper.getLocal(LOCAL_KEYS.USAGE_DATE)
          ]);
          return {
            count: count || 0,
            date: date || void 0
          };
        }
        static async setDailyUsage(usage) {
          await Promise.all([
            StorageWrapper.setLocal(LOCAL_KEYS.DAILY_USAGE_COUNT, usage.count),
            StorageWrapper.setLocal(LOCAL_KEYS.USAGE_DATE, usage.date)
          ]);
        }
        static async getUsageStats() {
          const [totalCalls, estimatedTokensIn, estimatedTokensOut] = await Promise.all([
            StorageWrapper.getLocal(LOCAL_KEYS.TOTAL_CALLS),
            StorageWrapper.getLocal(LOCAL_KEYS.TOKENS_IN),
            StorageWrapper.getLocal(LOCAL_KEYS.TOKENS_OUT)
          ]);
          return {
            totalCalls: totalCalls || 0,
            estimatedTokensIn: estimatedTokensIn || 0,
            estimatedTokensOut: estimatedTokensOut || 0
          };
        }
        static async setUsageStats(stats) {
          await Promise.all([
            StorageWrapper.setLocal(LOCAL_KEYS.TOTAL_CALLS, stats.totalCalls),
            StorageWrapper.setLocal(LOCAL_KEYS.TOKENS_IN, stats.estimatedTokensIn),
            StorageWrapper.setLocal(LOCAL_KEYS.TOKENS_OUT, stats.estimatedTokensOut)
          ]);
        }
        static async incrementUsageStats(inputTokens, outputTokens) {
          const stats = await this.getUsageStats();
          await this.setUsageStats({
            totalCalls: stats.totalCalls + 1,
            estimatedTokensIn: stats.estimatedTokensIn + inputTokens,
            estimatedTokensOut: stats.estimatedTokensOut + outputTokens
          });
        }
        static async resetUsageStats() {
          await this.setUsageStats({
            totalCalls: 0,
            estimatedTokensIn: 0,
            estimatedTokensOut: 0
          });
        }
      };
    }
  });

  // src/shared/configManager.ts
  var ConfigManager;
  var init_configManager = __esm({
    "src/shared/configManager.ts"() {
      "use strict";
      init_config();
      init_promptEasyStorage();
      ConfigManager = class {
        static async getManagedConfig() {
          return PromptEasyStorage.getManagedConfig();
        }
        static async ensureKey() {
          const config = await this.getManagedConfig();
          if (config?.apiKey) {
            return config.apiKey;
          }
          if (this.pendingFetch) {
            const result = await this.pendingFetch;
            return result.apiKey;
          }
          this.pendingFetch = this.fetchAndCacheConfig();
          try {
            const result = await this.pendingFetch;
            return result.apiKey;
          } finally {
            this.pendingFetch = null;
          }
        }
        static async fetchAndCacheConfig() {
          try {
            const response = await fetch(CONFIG_ENDPOINT_URL);
            if (!response.ok) {
              throw new Error(`HTTP ${response.status}`);
            }
            const config = await response.json();
            await PromptEasyStorage.setManagedConfig(config);
            return config;
          } catch (error) {
            await PromptEasyStorage.markKeyFetchFailed();
            throw new Error(`Failed to fetch API key configuration: ${error.message}`);
          }
        }
        static resetForTest() {
          this.pendingFetch = null;
        }
      };
      ConfigManager.pendingFetch = null;
    }
  });

  // src/popup/popup.ts
  var require_popup = __commonJS({
    "src/popup/popup.ts"() {
      init_serviceBus();
      init_configManager();
      init_improveError();
      document.addEventListener("DOMContentLoaded", async () => {
        const improveBtn = document.getElementById("improveBtn");
        const copyBtn = document.getElementById("copyBtn");
        const inputPrompt = document.getElementById("inputPrompt");
        const outputPrompt = document.getElementById("outputPrompt");
        const loadingOverlay = document.getElementById("loadingOverlay");
        const toast = document.getElementById("toast");
        const charCount = document.getElementById("charCount");
        const tokenEstimate = document.getElementById("tokenEstimate");
        let isKeyReady = false;
        const showToast = (message, type = "success") => {
          toast.textContent = message;
          toast.className = "";
          toast.classList.add(type === "success" ? "toast-success" : "toast-error");
          toast.classList.remove("hidden");
          setTimeout(() => {
            toast.classList.add("hidden");
          }, 3e3);
        };
        const updateStats = () => {
          const text = inputPrompt.value;
          const chars = text.length;
          const tokens = Math.ceil(chars / 4);
          charCount.textContent = `${chars} characters`;
          tokenEstimate.textContent = `~${tokens} tokens`;
          improveBtn.disabled = !isKeyReady || chars === 0;
        };
        inputPrompt.addEventListener("input", updateStats);
        improveBtn.addEventListener("click", async () => {
          const text = inputPrompt.value.trim();
          if (!text) return;
          improveBtn.disabled = true;
          loadingOverlay.classList.remove("hidden");
          outputPrompt.value = "";
          copyBtn.disabled = true;
          try {
            const result = await ServiceBus.improvePrompt(text);
            outputPrompt.value = result;
            copyBtn.disabled = false;
            showToast("Prompt improved successfully!");
          } catch (error) {
            showToast(getImproveErrorDisplayMessage(error), "error");
          } finally {
            loadingOverlay.classList.add("hidden");
            improveBtn.disabled = !isKeyReady || inputPrompt.value.trim().length === 0;
          }
        });
        copyBtn.addEventListener("click", async () => {
          const text = outputPrompt.value;
          if (!text) return;
          try {
            await navigator.clipboard.writeText(text);
            showToast("Copied to clipboard!");
          } catch (error) {
            showToast("Failed to copy to clipboard.", "error");
          }
        });
        updateStats();
        try {
          await ConfigManager.ensureKey();
          isKeyReady = true;
          updateStats();
        } catch (error) {
          showToast(getImproveErrorDisplayMessage({ errorCode: "KEY_NOT_READY", message: error.message }), "error");
          improveBtn.disabled = true;
        }
      });
    }
  });
  require_popup();
})();
//# sourceMappingURL=popup.js.map

"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/shared/improveError.ts
  function isImproveErrorCode(value) {
    return typeof value === "string" && value in DISPLAY_MESSAGES;
  }
  function getErrorMessage(error) {
    if (error instanceof Error) {
      return error.message;
    }
    const message = error?.message;
    if (typeof message === "string") {
      return message;
    }
    return String(error);
  }
  function normalizeReliableLLMError(error) {
    switch (error.type) {
      case "AUTHENTICATION":
        return new ImproveError("AUTHENTICATION", error.message);
      case "RATE_LIMIT":
      case "QUOTA_EXCEEDED":
        return new ImproveError("RATE_LIMITED", error.message);
      case "NETWORK":
        return new ImproveError("NETWORK_ERROR", error.message);
      case "UNSUPPORTED":
      case "UNKNOWN":
      default:
        return new ImproveError("UNKNOWN", error.message);
    }
  }
  function normalizeImproveError(error) {
    if (error instanceof ImproveError) {
      return error;
    }
    const reliableType = error?.type;
    if (typeof reliableType === "string") {
      return normalizeReliableLLMError({ type: reliableType, message: getErrorMessage(error) });
    }
    const errorCode = error?.errorCode;
    const message = getErrorMessage(error);
    if (isImproveErrorCode(errorCode)) {
      return new ImproveError(errorCode, message);
    }
    return new ImproveError("UNKNOWN", message);
  }
  function getImproveErrorDisplayMessage(error) {
    return normalizeImproveError(error).displayMessage;
  }
  var DISPLAY_MESSAGES, ImproveError;
  var init_improveError = __esm({
    "src/shared/improveError.ts"() {
      "use strict";
      DISPLAY_MESSAGES = {
        RATE_LIMITED: "This improve is rate limited. Please try again later.",
        KEY_NOT_READY: "Setting up your API key... please try again in a moment.",
        NETWORK_ERROR: "Network error. Check your connection and try again.",
        INPUT_EMPTY: "Enter a prompt to improve.",
        INPUT_TOO_LONG: "Input exceeds 500 tokens. Shorten and try again.",
        AUTHENTICATION: "API key invalid or unavailable. Try again in a moment.",
        UNKNOWN: "Improving failed. Please try again."
      };
      ImproveError = class extends Error {
        constructor(errorCode, debugMessage, displayMessage = DISPLAY_MESSAGES[errorCode]) {
          super(debugMessage);
          this.name = "ImproveError";
          this.errorCode = errorCode;
          this.displayMessage = displayMessage;
          this.debugMessage = debugMessage;
        }
      };
    }
  });

  // src/shared/serviceBus.ts
  var ServiceBus;
  var init_serviceBus = __esm({
    "src/shared/serviceBus.ts"() {
      "use strict";
      init_improveError();
      ServiceBus = class {
        /**
         * Send a request to the background script to improve a prompt
         */
        static async improvePrompt(text, context) {
          const response = await this.send({
            type: "IMPROVE_PROMPT" /* IMPROVE_PROMPT */,
            payload: { text, context }
          });
          if (!response.success) {
            const error = new Error(response.error || "Failed to improve prompt");
            error.errorCode = response.errorCode;
            error.debugMessage = response.debugMessage;
            throw error;
          }
          return response.data;
        }
        /**
         * Generic internal sender using long-lived ports for disconnect awareness
         */
        static send(message) {
          return new Promise((resolve, reject) => {
            const port = chrome.runtime.connect({ name: message.type });
            port.onMessage.addListener((response) => {
              port.disconnect();
              resolve(response);
            });
            port.onDisconnect.addListener(() => {
              if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message || "";
                if (errMsg.includes("Extension context invalidated")) {
                  reject(new Error("Extension was updated. Please refresh this page to continue using Prompt Easy."));
                } else {
                  reject(new Error(errMsg));
                }
              } else {
                reject(new Error("Connection to service worker lost."));
              }
            });
            port.postMessage(message);
          });
        }
        /**
         * Helper for background script to listen for typed messages.
         * The handler receives (type, payload, abortSignal) where abortSignal
         * fires when the caller disconnects (e.g., popup closes).
         */
        static addListener(handler) {
          chrome.runtime.onConnect.addListener((port) => {
            const abortController = new AbortController();
            port.onDisconnect.addListener(() => {
              abortController.abort();
            });
            port.onMessage.addListener((message) => {
              handler(message.type, message.payload, abortController.signal).then((data) => port.postMessage({ success: true, data })).catch((error) => {
                if (abortController.signal.aborted) {
                  return;
                }
                const improveError = normalizeImproveError(error);
                port.postMessage({
                  success: false,
                  error: improveError.displayMessage,
                  errorCode: improveError.errorCode,
                  debugMessage: improveError.debugMessage
                });
              });
            });
          });
        }
      };
    }
  });

  // src/content/adapters/interface.ts
  var BaseAdapter;
  var init_interface = __esm({
    "src/content/adapters/interface.ts"() {
      "use strict";
      BaseAdapter = class {
        getText(composer) {
          if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
            return composer.value;
          }
          return composer.innerText || composer.textContent || "";
        }
        setText(composer, text) {
          if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
            composer.value = text;
            composer.dispatchEvent(new Event("input", { bubbles: true }));
            composer.dispatchEvent(new Event("change", { bubbles: true }));
          } else {
            composer.textContent = text;
            composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
          }
        }
      };
    }
  });

  // src/content/adapters/registry.ts
  function getActiveAdapter() {
    return ALL_ADAPTERS.find((a) => a.match()) || null;
  }
  var ChatGPTAdapter, ClaudeAdapter, GeminiAdapter, PerplexityAdapter, ALL_ADAPTERS;
  var init_registry = __esm({
    "src/content/adapters/registry.ts"() {
      "use strict";
      init_interface();
      ChatGPTAdapter = class extends BaseAdapter {
        constructor() {
          super(...arguments);
          this.name = "ChatGPT";
        }
        match() {
          return window.location.host.includes("chatgpt.com");
        }
        getComposer() {
          return document.querySelector("#prompt-textarea");
        }
        getButtonStyles() {
          return { right: "40px", bottom: "10px" };
        }
      };
      ClaudeAdapter = class extends BaseAdapter {
        constructor() {
          super(...arguments);
          this.name = "Claude";
        }
        match() {
          return window.location.host.includes("claude.ai");
        }
        getComposer() {
          return document.querySelector('div[contenteditable="true"].ProseMirror');
        }
        getButtonStyles() {
          return { right: "12px", bottom: "12px" };
        }
      };
      GeminiAdapter = class extends BaseAdapter {
        constructor() {
          super(...arguments);
          this.name = "Gemini";
        }
        match() {
          return window.location.host.includes("gemini.google.com");
        }
        getComposer() {
          const rich = document.querySelector("rich-textarea");
          if (rich) {
            const editable = rich.querySelector('[contenteditable="true"]');
            if (editable) return editable;
            return rich;
          }
          return document.querySelector("textarea");
        }
        getButtonStyles() {
          return { right: "16px", bottom: "16px" };
        }
      };
      PerplexityAdapter = class extends BaseAdapter {
        constructor() {
          super(...arguments);
          this.name = "Perplexity";
        }
        match() {
          return window.location.host.includes("perplexity.ai");
        }
        getComposer() {
          return document.querySelector('textarea[placeholder*="Ask"], textarea');
        }
        getButtonStyles() {
          return { right: "12px", bottom: "12px" };
        }
      };
      ALL_ADAPTERS = [
        new ChatGPTAdapter(),
        new ClaudeAdapter(),
        new GeminiAdapter(),
        new PerplexityAdapter()
      ];
    }
  });

  // src/content/composerSession.ts
  function findGenericComposer() {
    return document.querySelector('textarea, input[type="text"], [contenteditable="true"]');
  }
  function readGenericText(composer) {
    if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
      return composer.value;
    }
    return composer.innerText || composer.textContent || "";
  }
  function writeGenericText(composer, text) {
    if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
      composer.value = text;
      composer.dispatchEvent(new Event("input", { bubbles: true }));
      composer.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    composer.textContent = text;
    composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
  }
  var ComposerSession;
  var init_composerSession = __esm({
    "src/content/composerSession.ts"() {
      "use strict";
      init_registry();
      ComposerSession = class _ComposerSession {
        constructor(composer, adapter = null, source) {
          this.composer = composer;
          this.adapter = adapter;
          this.source = source ?? (adapter ? "site-adapter" : "generic-fallback");
        }
        static forActiveSite() {
          const adapter = getActiveAdapter();
          if (!adapter) {
            return null;
          }
          return this.fromAdapter(adapter);
        }
        static forFallback() {
          const adapter = getActiveAdapter();
          const adapterSession = adapter ? this.fromAdapter(adapter) : null;
          if (adapterSession) {
            return adapterSession;
          }
          const composer = findGenericComposer();
          return composer ? new _ComposerSession(composer) : null;
        }
        static fromAdapter(adapter) {
          const composer = adapter.getComposer();
          return composer ? new _ComposerSession(composer, adapter, "site-adapter") : null;
        }
        get siteName() {
          return this.adapter?.name ?? null;
        }
        get container() {
          return this.composer.parentElement;
        }
        get buttonStyles() {
          return this.adapter?.getButtonStyles() ?? {};
        }
        get buttonTitle() {
          return this.adapter ? `Improve Prompt on ${this.adapter.name} (Prompt Easy)` : "Improve Prompt (Prompt Easy Fallback)";
        }
        readPrompt() {
          return this.adapter ? this.adapter.getText(this.composer) : readGenericText(this.composer);
        }
        writePrompt(text) {
          if (this.adapter) {
            this.adapter.setText(this.composer, text);
            return;
          }
          writeGenericText(this.composer, text);
        }
        focus() {
          this.composer.focus();
        }
      };
    }
  });

  // src/content/toast.ts
  function getErrorMessage2(error) {
    return getImproveErrorDisplayMessage(error);
  }
  function showToast(referenceElement, message) {
    const existing = document.getElementById(TOAST_ID);
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = TOAST_ID;
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "absolute",
      bottom: "100%",
      left: "50%",
      transform: "translateX(-50%)",
      marginBottom: "8px",
      backgroundColor: "rgba(0, 0, 0, 0.85)",
      color: "white",
      padding: "8px 12px",
      borderRadius: "6px",
      fontSize: "13px",
      whiteSpace: "nowrap",
      zIndex: "10000",
      pointerEvents: "none",
      opacity: "0",
      transition: "opacity 0.2s ease-in-out"
    });
    const refStyle = window.getComputedStyle(referenceElement);
    if (refStyle.position === "static") {
      referenceElement.style.position = "relative";
    }
    referenceElement.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
    });
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 200);
    }, TOAST_DURATION_MS);
  }
  var TOAST_ID, TOAST_DURATION_MS;
  var init_toast = __esm({
    "src/content/toast.ts"() {
      "use strict";
      init_improveError();
      TOAST_ID = "prompt-easy-toast";
      TOAST_DURATION_MS = 3e3;
    }
  });

  // src/content/content.ts
  var require_content = __commonJS({
    "src/content/content.ts"() {
      init_serviceBus();
      init_composerSession();
      init_toast();
      console.log("Prompt Easy: Content script initialized with ServiceBus");
      var BUTTON_ID = "prompt-easy-improve-btn";
      var FALLBACK_ID = "prompt-easy-fallback-btn";
      var IMPROVE_ICON = "\u26A1";
      var isFallbackHidden = false;
      function debounce(fn, ms = 500) {
        let timeoutId;
        return function(...args) {
          clearTimeout(timeoutId);
          timeoutId = setTimeout(() => fn.apply(this, args), ms);
        };
      }
      function injectFloatingButton() {
        if (isFallbackHidden || document.getElementById(FALLBACK_ID)) return;
        const button = document.createElement("button");
        button.id = FALLBACK_ID;
        button.type = "button";
        button.innerHTML = `${IMPROVE_ICON} Improve`;
        button.title = "Improve Prompt (Prompt Easy Fallback)";
        Object.assign(button.style, {
          position: "fixed",
          bottom: "24px",
          right: "24px",
          zIndex: "9999",
          backgroundColor: "#4a90e2",
          color: "white",
          border: "none",
          borderRadius: "24px",
          padding: "8px 16px",
          fontSize: "14px",
          fontWeight: "bold",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: "8px",
          boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
          transition: "transform 0.2s, background-color 0.2s"
        });
        const closeBtn = document.createElement("span");
        closeBtn.innerHTML = "\xD7";
        closeBtn.style.fontSize = "18px";
        closeBtn.style.marginLeft = "4px";
        closeBtn.style.cursor = "pointer";
        closeBtn.onclick = (e) => {
          e.stopPropagation();
          isFallbackHidden = true;
          button.remove();
        };
        button.appendChild(closeBtn);
        button.onclick = async () => {
          const session = ComposerSession.forFallback();
          const text = session?.readPrompt().trim() || "";
          if (!text.trim()) {
            showToast(button, "Could not find prompt text. Please type something first.");
            return;
          }
          try {
            button.disabled = true;
            button.style.opacity = "0.7";
            const result = await ServiceBus.improvePrompt(text);
            session.writePrompt(result);
            session.focus();
          } catch (error) {
            showToast(button, getErrorMessage2(error));
          } finally {
            button.disabled = false;
            button.style.opacity = "1";
          }
        };
        document.body.appendChild(button);
      }
      function injectImproveButton() {
        const session = ComposerSession.forActiveSite();
        if (!session) {
          const oldBtn = document.getElementById(BUTTON_ID);
          if (oldBtn) oldBtn.remove();
          injectFloatingButton();
          return;
        }
        const fallback = document.getElementById(FALLBACK_ID);
        if (fallback) fallback.remove();
        const container = session.container;
        if (!container) return;
        const existingBtn = document.getElementById(BUTTON_ID);
        if (existingBtn && existingBtn.parentElement === container) return;
        if (existingBtn) existingBtn.remove();
        const button = document.createElement("button");
        button.id = BUTTON_ID;
        button.type = "button";
        button.innerHTML = IMPROVE_ICON;
        button.title = session.buttonTitle;
        Object.assign(button.style, {
          position: "absolute",
          zIndex: "1000",
          backgroundColor: "#4a90e2",
          color: "white",
          border: "none",
          borderRadius: "4px",
          width: "28px",
          height: "28px",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "16px",
          boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
          ...session.buttonStyles
        });
        button.addEventListener("click", async (e) => {
          e.preventDefault();
          e.stopPropagation();
          const text = session.readPrompt().trim();
          if (!text) return;
          try {
            button.innerHTML = '<span class="prompt-easy-spinner"></span>';
            button.disabled = true;
            const result = await ServiceBus.improvePrompt(text);
            session.writePrompt(result);
            session.focus();
          } catch (error) {
            showToast(button, getErrorMessage2(error));
          } finally {
            button.innerHTML = IMPROVE_ICON;
            button.disabled = false;
          }
        });
        const containerStyle = window.getComputedStyle(container);
        if (containerStyle.position === "static") {
          container.style.position = "relative";
        }
        container.appendChild(button);
      }
      injectImproveButton();
      var debouncedInject = debounce(injectImproveButton, 500);
      var observer = new MutationObserver(() => debouncedInject());
      observer.observe(document.body, { childList: true, subtree: true });
      setInterval(debouncedInject, 3e3);
    }
  });
  require_content();
})();
//# sourceMappingURL=content.js.map
